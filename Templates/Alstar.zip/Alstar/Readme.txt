Thanks for downloading this theme!

Theme Name: Alstar
Theme URL: https://bootstrapmade.com/alstar-free-parallax-bootstrap-template/
Author: BootstrapMade.com
Author URL: https://bootstrapmade.com
